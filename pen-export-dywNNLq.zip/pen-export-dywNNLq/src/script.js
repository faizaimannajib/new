// script.js

// Example JavaScript code (You can add your own functionality here)
document.addEventListener("DOMContentLoaded", function() {
    // You can add JavaScript interactions here
});
